<script>
  import { onMount } from 'svelte';
  import { tweened } from 'svelte/motion';

  function scrollIntoView(event) {
    event.preventDefault();
    const targetId = event.target.getAttribute('href');
    const targetSection = document.querySelector(targetId);
    if (targetSection) {
      targetSection.scrollIntoView({
        behavior: 'smooth'
      });
    }
  }

  const messages = [
    "Discover Exciting Opportunities",
    "Explore Job Openings",
    "Unlock Your Career Potential",
    "Start Your Career Journey",
    "Find Your Dream Job",
    "Empowering Students with Employment",
    "Search for Internships and Jobs",
    "Connecting Students with Employers",
    "Navigate Your Path to Success",
    "Transforming Student Careers",
    "Access Exclusive Job Listings",
    "Build Your Future Here",
    "Join Our Community of Career Seekers",
    "Your Gateway to Professional Growth",
    "Find Employment Tailored to You",
    "Empowering Students to Thrive in the Workforce",
    "Seize Opportunities, Shape Your Future",
    "Discover Career Paths and Opportunities",
    "Elevate Your Career Prospects",
    "Your Source for Job Search Success"
];



function typewriter(node, { speed = 1 }) {
 
    const valid = node.childNodes.length === 1 && node.childNodes[0].nodeType === Node.TEXT_NODE;


    if (!valid) {
        throw new Error(`This transition only works on elements with a single text node child`);
    }

    const text = node.textContent;
    

    const duration = text.length / (speed * 0.01);


    return {
        duration,
        tick: (t) => {
            const i = Math.trunc(text.length * t);
            
            
            node.textContent = text.slice(0, i);
        }
    };
}

let i = 0;
function paint(context, t) {
    const { width, height } = context.canvas;
    const imageData = context.getImageData(0, 0, width, height);
    

    const maxDistance = Math.sqrt(Math.pow(width / 2, 2) + Math.pow(height / 2, 2));


    for (let p = 0; p < imageData.data.length; p += 1) {
        const d = p / 1/100;
        const x = d % width;
        const y = (d / width) >>> 0;

        const distance = Math.sqrt(Math.pow(x - width / 2, 2) + Math.pow(y - height / 2, 2));

        const progress = distance / maxDistance;


        const red = 255 * progress * Math.sin(t / 3000);
        const green = 255 * progress * Math.cos(t / 3000);
        const blue = 255 * progress * Math.sin(t / 3000 + Math.PI / 2);

        imageData.data[p + 0] = red;  
        imageData.data[p + 1] = green; 
        imageData.data[p + 2] = blue; 
        imageData.data[p + 3] = 255;   
    }

    context.putImageData(imageData, 0, 0);
}


onMount(() => {
    
    const interval = setInterval(() => {
        
        i += 1;
        
        i %= messages.length;
    }, 2500);

    const canvas = document.querySelector('canvas');
		const context = canvas.getContext('2d');

		let frame = requestAnimationFrame(function loop(t) {
			frame = requestAnimationFrame(loop);
			paint(context, t);
		});

    return () => {
      cancelAnimationFrame(frame);
      clearInterval(interval);
    };
  });
</script>



<style>
	canvas {
    background-color: #301c1c;
    mask: url('data:image/svg+xml;utf8,<svg fill="%23ffffff" width="84px" height="84px" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" stroke="%23ffffff"><path d="M22,23H17V21h5V19H19a2,2,0,0,1-2-2V15a2,2,0,0,1,2-2h5v2H19v2h3a2,2,0,0,1,2,2v2A2,2,0,0,1,22,23Z"></path><path d="M13,23H7V21h6V17H9a2,2,0,0,1-2-2V11A2,2,0,0,1,9,9h6v2H9v4h4a2,2,0,0,1,2,2v4A2,2,0,0,1,13,23Z"></path></svg>') 50% 50% no-repeat;
		-webkit-mask: url('data:image/svg+xml;utf8,<svg fill="%23ffffff" width="84px" height="84px" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" stroke="%23ffffff"><path d="M22,23H17V21h5V19H19a2,2,0,0,1-2-2V15a2,2,0,0,1,2-2h5v2H19v2h3a2,2,0,0,1,2,2v2A2,2,0,0,1,22,23Z"></path><path d="M13,23H7V21h6V17H9a2,2,0,0,1-2-2V11A2,2,0,0,1,9,9h6v2H9v4h4a2,2,0,0,1,2,2v4A2,2,0,0,1,13,23Z"></path></svg>') 50% 50% no-repeat;
	}

  
</style>



<section>
  <header>
    
    <div class="bg-indigo-400 text-white py-8">
      <div class=" lg:flex justify-between items-center container mx-auto gap-4">
        <div class="flex items-center">
          <button>
            <canvas width={50} height={50}/>
          </button>
            <div class="border-l-2 border-white h-10 m-4">
              <button class=" px-8 font-mono text-white font-bold text-4xl rounded">
                STUDENTSEEKER
              </button>
            </div> 
          </div>
          <div class="border-t-2 border-white lg:hidden "></div>
          <nav class="flex flex-col items-center lg:block">
            <a class="py-4 font-mono text-white font-bold text-3xl lg:text-2xl lg:px-3 rounded" href="#section1" on:click|preventDefault={scrollIntoView}>Studerende</a>
            
            <a class=" py-4 font-mono text-white font-bold text-3xl lg:text-2xl lg:px-2 rounded" href="#section2" on:click|preventDefault={scrollIntoView}>Virksomhed</a>
          
            <a class="py-4 font-mono text-white font-bold text-3xl lg:text-2xl lg:px-3 rounded" href="#section3" on:click|preventDefault={scrollIntoView}>Om</a>
         
            <a class=" py-4 font-mono text-white font-bold text-3xl lg:text-2xl lg:px-2 rounded" href="#section4" on:click|preventDefault={scrollIntoView}>Kontakt</a>
            
          </nav>
        </div>
      </div>

  
    
    <div class="w-full min-h-screen bg-blue-200 h-screen py-40">
      <div class="container mx-auto flex items-center justify-center ">
          <div class="text-container w-1/2 md: w-full">
            <h2 class="text-3xl font-bold mb-4 md:text-center px-4">Opdag karriermuligheder, skræddersyet til studerende</h2>
            <p class="text-lg font-semibold md:text-center pr-8">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod libero vel ex hendrerit efficitur.
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod libero vel ex hendrerit efficitur.
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod libero vel ex hendrerit efficitur.
            </p>
        </div>
          <div class="w-full h-full hidden md:block pl-8">
          <img class=" border-4 rounded border-black" src="ttt.png" alt="img">
          </div>  
      </div>
      <div class="pt-32 text-center">
        <h2 class="text-4xl font-semibold">  
        {#key i}
          <p in:typewriter={{ speed: 5 }}>
            {messages[i] || ''}
          </p>
        {/key}
        </h2>
      </div>
    </div>
  
  </header>
</section>



<body>
 
  
  <section id="section1" class="flex">
    <!-- Part 1: Text and Button -->
    <div class="min-h-screen bg-blue-300 flex-1 flex justify-center items-center">
      <div class="container mx-auto px-4 py-16">
        <h1 class="text-5xl font-mono font-medium">Studerende</h1>

        <div class="font-mono max-w-3xl">
          <h1 class="py-8 text-xl font-bold">StudentSeeker - Din Studenter Service</h1>
          <p>Velkommen til tudentSeeker, skabt af studerende for studerende! Vi forstår udfordringerne ved studielivet, og vores mål er at gøre det lettere og mere givende for dig.</p>
          <p>StudentSeeker tilbyder personlig studievejledning, hvor erfarne studerende deler indsigt om fagvalg, studieteknikker og karriereveje. Vi skaber et fællesskab, hvor studerende støtter hinanden.</p>
          <p>Få eksklusive studierabatter på relevante materialer, software og nødvendigheder. Vi stræber efter at lette økonomien for studerende.</p>
          <p>STUDENTSEEKER er mere end en service; det er en bevægelse. Deltag i vores fællesskab, del dine erfaringer, og skab en mere støttende studiekultur.</p>
          <p>Tilmeld dig STUDENTSEEKER i dag for at gøre dine studieår problemfri og meningsfulde!</p>
          <div class="py-8">
            <button class="text-2xl px-4 font-bold py-0.5 border-4 border-indigo-400 bg-white rounded">
              <a data-sveltekit-preload-data="tap" href="/register">Tilmeld dig nu!</a>
            </button>
          </div>
        </div>
      </div>
    </div>
  
    <!-- Part 2: Images -->
    <div class="min-h-screen bg-blue-300 flex-1 flex justify-center items-center font-bold font-mono">
      <div class="container mx-auto px-4 py-16">
        <div class="md:grid grid-cols-3 gap-8">
          <!-- Image 1 -->
          <div class="py-8 md:relative flex flex-col items-center ">
            <div class="text-center mt-2 text-2xl">
              Step 1
            </div>
            <div class="max-w-full h-auto rounded-lg overflow-hidden flex justify-center items-center">
             <svg fill="#000000" height="140px" width="120px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.00 512.00" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g transform="translate(1 1)"> <g> <g> <path d="M373.576,92.448c5.828-6.13,9.424-14.401,9.424-23.475c0-18.773-15.36-34.133-34.133-34.133 c-18.773,0-34.133,15.36-34.133,34.133c0,9.075,3.596,17.345,9.424,23.475c-15.76,8.754-26.491,25.578-26.491,44.792v40.96 c0,5.12,3.413,8.533,8.533,8.533s8.533-3.413,8.533-8.533v-40.96c0-18.773,15.36-34.133,34.133-34.133 c18.773,0,34.133,15.36,34.133,34.133v40.96c0,5.12,3.413,8.533,8.533,8.533s8.533-3.413,8.533-8.533v-40.96 C400.067,118.026,389.336,101.203,373.576,92.448z M331.8,68.973c0-9.387,7.68-17.067,17.067-17.067 c9.387,0,17.067,7.68,17.067,17.067s-7.68,17.067-17.067,17.067C339.48,86.04,331.8,78.36,331.8,68.973z"></path> <path d="M425.667-1H84.333c-14.507,0-25.6,11.093-25.6,25.6v460.8c0,14.507,11.093,25.6,25.6,25.6h341.333 c14.507,0,25.6-11.093,25.6-25.6V24.6C451.267,10.093,440.173-1,425.667-1z M434.2,485.4c0,5.12-3.413,8.533-8.533,8.533H84.333 c-5.12,0-8.533-3.413-8.533-8.533V24.6c0-5.12,3.413-8.533,8.533-8.533h341.333c5.12,0,8.533,3.413,8.533,8.533V485.4z"></path> <path d="M391.533,220.867H118.467c-5.12,0-8.533,3.413-8.533,8.533s3.413,8.533,8.533,8.533h273.067 c5.12,0,8.533-3.413,8.533-8.533S396.653,220.867,391.533,220.867z"></path> <path d="M391.533,340.333H118.467c-5.12,0-8.533,3.413-8.533,8.533s3.413,8.533,8.533,8.533h273.067 c5.12,0,8.533-3.413,8.533-8.533S396.653,340.333,391.533,340.333z"></path> <path d="M306.2,263.533h-42.667c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533H306.2 c5.12,0,8.533-3.413,8.533-8.533C314.733,266.947,311.32,263.533,306.2,263.533z"></path> <path d="M348.867,280.6c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-8.533c-5.12,0-8.533,3.413-8.533,8.533 c0,5.12,3.413,8.533,8.533,8.533H348.867z"></path> <path d="M263.533,314.733h25.6c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-25.6c-5.12,0-8.533,3.413-8.533,8.533 S258.413,314.733,263.533,314.733z"></path> <path d="M314.733,306.2c0,5.12,3.413,8.533,8.533,8.533H383c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-59.733 C318.147,297.667,314.733,301.08,314.733,306.2z"></path> <path d="M118.467,280.6h42.667c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-42.667 c-5.12,0-8.533,3.413-8.533,8.533C109.933,277.187,113.347,280.6,118.467,280.6z"></path> <path d="M203.8,280.6c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-8.533c-5.12,0-8.533,3.413-8.533,8.533 c0,5.12,3.413,8.533,8.533,8.533H203.8z"></path> <path d="M297.667,391.533c0-5.12-3.413-8.533-8.533-8.533h-25.6c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533 h25.6C294.253,400.067,297.667,396.653,297.667,391.533z"></path> <path d="M383,383h-59.733c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533H383c5.12,0,8.533-3.413,8.533-8.533 C391.533,386.413,388.12,383,383,383z"></path> <path d="M323.267,417.133h-25.6c-5.12,0-8.533,3.413-8.533,8.533s3.413,8.533,8.533,8.533h25.6c5.12,0,8.533-3.413,8.533-8.533 S328.387,417.133,323.267,417.133z"></path> <path d="M383,417.133h-25.6c-5.12,0-8.533,3.413-8.533,8.533s3.413,8.533,8.533,8.533H383c5.12,0,8.533-3.413,8.533-8.533 S388.12,417.133,383,417.133z"></path> <path d="M161.133,383h-42.667c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533h42.667 c5.12,0,8.533-3.413,8.533-8.533C169.667,386.413,166.253,383,161.133,383z"></path> <path d="M203.8,383h-8.533c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533h8.533 c5.12,0,8.533-3.413,8.533-8.533C212.333,386.413,208.92,383,203.8,383z"></path> <path d="M118.467,84.333H178.2c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-59.733 c-5.12,0-8.533,3.413-8.533,8.533S113.347,84.333,118.467,84.333z"></path> <path d="M118.467,152.6H178.2c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-59.733 c-5.12,0-8.533,3.413-8.533,8.533C109.933,149.187,113.347,152.6,118.467,152.6z"></path> <path d="M212.333,84.333h8.533c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-8.533c-5.12,0-8.533,3.413-8.533,8.533 S207.213,84.333,212.333,84.333z"></path> <path d="M212.333,118.467H255c5.12,0,8.533-3.413,8.533-8.533S260.12,101.4,255,101.4h-42.667c-5.12,0-8.533,3.413-8.533,8.533 S207.213,118.467,212.333,118.467z"></path> <path d="M212.333,152.6h8.533c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-8.533 c-5.12,0-8.533,3.413-8.533,8.533C203.8,149.187,207.213,152.6,212.333,152.6z"></path> <path d="M212.333,186.733H255c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-42.667c-5.12,0-8.533,3.413-8.533,8.533 S207.213,186.733,212.333,186.733z"></path> </g> </g> </g> </g></svg>
            </div>
            <div class="text-center mt-2">
              Opret gratis profil
            </div>
          </div>
  
          <!-- Image 2 -->
          <div class="py-8 md:relative flex flex-col items-center">
            <div class="text-center mt-2 text-2xl">
              Step 2
            </div>
            <div class="max-w-full h-auto rounded-lg overflow-hidden flex justify-center items-center">
              <svg height="140px" width="140px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 392.663 392.663" xml:space="preserve" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <polygon style="fill:#93c5fd;" points="167.758,310.432 147.588,350.901 244.945,350.901 224.776,310.432 "></polygon> <path style="fill:#FFFFFF;" d="M360.986,41.762H31.547c-5.301,0-9.632,4.331-9.632,9.632v227.556c0,5.301,4.331,9.632,9.632,9.632 h329.568c5.301,0,9.632-4.331,9.632-9.632V51.394C370.747,46.093,366.416,41.762,360.986,41.762z"></path> <path style="fill:#000000;" d="M360.986,19.911H31.547C14.158,19.911,0,34.069,0,51.459v227.556 c0,17.39,14.158,31.547,31.547,31.547h111.903l-23.208,46.416c-3.62,7.24,1.616,15.774,9.762,15.774h132.655 c8.145,0,13.382-8.469,9.762-15.774l-23.208-46.416h111.903c17.39,0,31.547-14.158,31.547-31.547V51.459 C392.533,34.069,378.376,19.911,360.986,19.911z M370.747,279.014c0,5.301-4.331,9.632-9.632,9.632H31.547 c-5.301,0-9.632-4.331-9.632-9.632V51.459c0-5.301,4.331-9.632,9.632-9.632h329.568c5.301,0,9.632,4.331,9.632,9.632V279.014z M147.588,350.901l20.17-40.404h57.018l20.17,40.404H147.588z"></path> <path style="fill:#93c5fd;" d="M338.036,63.547H54.562c-6.012,0-10.925,4.848-10.925,10.925v1.422h25.277 c6.012,0,10.925,4.848,10.925,10.925c0,6.077-4.848,10.925-10.925,10.925H43.636v18.941h1.616c6.012,0,10.925,4.848,10.925,10.925 c0,6.012-4.848,10.925-10.796,10.925h-1.681v117.592c0,6.012,4.848,10.925,10.925,10.925h283.539 c6.012,0,10.925-4.848,10.925-10.925V74.473C349.026,68.461,344.048,63.547,338.036,63.547z"></path> <circle style="fill:#FFFFFF;" cx="188.38" cy="164.978" r="27.927"></circle> <g> <path style="fill:#000000;" d="M230.529,191.03c4.719-7.564,7.434-16.485,7.434-26.053c0-27.345-22.174-49.519-49.519-49.519 s-49.519,22.174-49.519,49.519c0,27.345,22.174,49.519,49.519,49.519c9.891,0,19.071-2.909,26.828-7.952l41.051,41.051 c4.267,4.267,11.119,4.267,15.451,0c4.267-4.202,4.267-11.055,0-15.386L230.529,191.03z M188.38,192.84 c-15.386,0-27.927-12.412-27.927-27.927c0-15.386,12.541-27.927,27.927-27.927s27.927,12.541,27.927,27.927 C216.307,180.364,203.766,192.84,188.38,192.84z"></path> <path style="fill:#000000;" d="M74.667,136.598h27.604v43.636c0,11.766-7.758,13.576-10.667,13.576 c-6.077,0-11.96-3.038-17.519-9.051l-10.796,14.933c8.339,8.598,18.101,12.929,29.285,12.929c8.986,0,30.578-3.297,30.578-33.164 V118.82h-48.42v17.778H74.667z"></path> <path style="fill:#000000;" d="M335.386,186.053c-0.259-19.523-19.006-22.497-19.006-22.497s13.77-3.232,13.77-20.17 c0-26.893-32.905-24.63-32.905-24.63h-36.331v93.22h40.792C337.002,213.01,335.386,186.053,335.386,186.053z M281.665,136.339 h0.065h9.956c6.723,0.323,17.131-0.84,16.937,10.214c0,5.43-1.228,9.891-17.067,9.891h-9.891L281.665,136.339L281.665,136.339z M295.952,194.327h-14.287v-21.463h12.283c8.275,0.388,20.105-0.453,19.846,10.602C313.859,187.733,313.277,194.65,295.952,194.327 z"></path> </g> </g></svg>
            </div>
            <div class="text-center mt-2">
              <p>Bliv opdaget af virksomeder og modtag jobtilbud der matcher dine kompentencer</p>
            </div>
          </div>
  
          <!-- Image 3 -->
          <div class="py-8 md:relative flex flex-col items-center">
            <div class="text-center mt-2 text-2xl">
              Step 3
            </div>
            <div class="max-w-full h-auto rounded-lg overflow-hidden flex justify-center items-center">
              <svg height="141px" width="141px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 495.62 495.62" xml:space="preserve" fill="#000000" transform="rotate(0)matrix(1, 0, 0, 1, 0, 0)"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <path style="fill:#000000;" d="M495.622,113.089v150.03c0,0-32.11,6.326-38.725,7.158c-6.594,0.83-27.316,7.521-42.334-6.914 c-23.16-22.197-105.447-104.03-105.447-104.03s-14.188-13.922-36.969-1.89c-20.912,11.022-51.911,27.175-64.859,33.465 c-24.477,13.028-44.764-7.642-44.764-23.387c0-12.213,7.621-20.502,18.515-26.598c29.524-17.898,91.752-52.827,117.67-66.598 c15.754-8.379,27.105-9.097,48.734,9.124c26.638,22.403,50.344,42.824,50.344,42.824s7.732,6.453,20.063,3.854 C448.13,123.725,495.622,113.089,495.622,113.089z M168.098,367.3c3.985-10.238,2.653-21.689-4.987-29.545 c-6.865-7.027-16.888-8.879-26.445-6.689c2.673-9.479,1.197-19.568-5.705-26.688c-6.886-7.009-16.89-8.898-26.446-6.688 c2.653-9.465,1.181-19.553-5.725-26.652c-10.814-11.092-29.519-10.616-41.807,1.097c-12.223,11.729-20.053,32.979-9.144,45.487 c10.891,12.445,23.405,4.873,32.945,2.699c-2.654,9.465-10.606,18.269-0.813,30.658c9.784,12.395,23.404,4.875,32.954,2.721 c-2.663,9.429-10.268,19.117-0.851,30.604c9.502,11.522,25.065,5.383,35.344,2.19c-3.967,10.199-12.458,21.193-1.549,33.513 c10.892,12.409,36.063,6.668,48.358-5.063c12.262-11.729,13.439-30.318,2.654-41.445 C189.435,365.865,178.335,364.089,168.098,367.3z M392.442,289.246c-88.88-88.881-47.075-47.058-94.906-94.992 c0,0-14.375-14.311-33.321-5.998c-13.3,5.828-30.423,13.771-43.307,19.835c-14.158,7.424-24.347,9.722-29.131,9.69 c-27.37-0.179-49.576-22.178-49.576-49.521c0-17.738,9.417-33.181,23.462-41.947c19.75-13.667,65.21-37.847,65.21-37.847 s-13.849-17.549-44.187-17.549c-30.329,0-93.695,41.512-93.695,41.512s-17.976,11.514-43.601,1.143L0,96.373V268.05 c0,0,14.103,4.082,26.775,9.258c2.862-8.162,7.48-15.699,13.886-21.924c21.023-20.024,55.869-20.232,74.996-0.537 c5.762,5.987,9.783,13.129,11.835,21.024c7.707,2.379,14.688,6.593,20.298,12.373c5.779,5.947,9.785,13.129,11.854,20.984 c7.698,2.381,14.669,6.611,20.298,12.395c6.339,6.537,10.562,14.433,12.534,22.988c8.047,2.344,15.319,6.705,21.176,12.693 c11.495,11.807,15.575,27.826,13.103,43.278c0.02,0,0.058,0,0.076,0.035c0.188,0.246,7.122,7.976,11.446,12.336 c8.474,8.482,22.311,8.482,30.811,0c8.444-8.479,8.481-22.289,0-30.811c-0.304-0.303-30.572-31.963-28.136-34.418 c2.418-2.438,40.981,37.688,41.699,38.422c8.463,8.465,22.291,8.465,30.792,0c8.481-8.479,8.463-22.289,0-30.791 c-0.416-0.396-2.152-2.059-2.796-2.721c0,0-38.234-34.06-35.324-36.97c2.946-2.928,50.438,41.392,50.515,41.392 c8.537,7.688,21.687,7.631,29.9-0.586c7.991-7.99,8.162-20.629,1.078-29.146c-0.15-0.453-36.194-38.121-33.381-40.955 c2.854-2.871,38.519,33.853,38.594,33.929c8.444,8.463,22.291,8.463,30.792,0c8.463-8.464,8.463-22.291,0-30.83 C392.706,289.396,392.555,289.32,392.442,289.246z"></path> </g> </g></svg>
            </div>
            <div class="text-center mt-2">
              <p>Start dit nye studie job</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  


  <section id="section2" class="flex">

      <!-- Part 2: Images -->
      <div class="min-h-screen bg-blue-200 flex-1 flex justify-center items-center font-bold font-mono">
        <div class="container mx-auto px-4 py-16">
          <div class="md:grid grid-cols-3 gap-8">
            <!-- Image 1 -->
            <div class="py-8 md:relative flex flex-col items-center">
              <div class="text-center mt-2 text-2xl">
                Step 1
              </div>
              <div class="max-w-full h-auto rounded-lg overflow-hidden flex justify-center items-center">
               <svg fill="#000000" height="140px" width="120px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.00 512.00" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g transform="translate(1 1)"> <g> <g> <path d="M373.576,92.448c5.828-6.13,9.424-14.401,9.424-23.475c0-18.773-15.36-34.133-34.133-34.133 c-18.773,0-34.133,15.36-34.133,34.133c0,9.075,3.596,17.345,9.424,23.475c-15.76,8.754-26.491,25.578-26.491,44.792v40.96 c0,5.12,3.413,8.533,8.533,8.533s8.533-3.413,8.533-8.533v-40.96c0-18.773,15.36-34.133,34.133-34.133 c18.773,0,34.133,15.36,34.133,34.133v40.96c0,5.12,3.413,8.533,8.533,8.533s8.533-3.413,8.533-8.533v-40.96 C400.067,118.026,389.336,101.203,373.576,92.448z M331.8,68.973c0-9.387,7.68-17.067,17.067-17.067 c9.387,0,17.067,7.68,17.067,17.067s-7.68,17.067-17.067,17.067C339.48,86.04,331.8,78.36,331.8,68.973z"></path> <path d="M425.667-1H84.333c-14.507,0-25.6,11.093-25.6,25.6v460.8c0,14.507,11.093,25.6,25.6,25.6h341.333 c14.507,0,25.6-11.093,25.6-25.6V24.6C451.267,10.093,440.173-1,425.667-1z M434.2,485.4c0,5.12-3.413,8.533-8.533,8.533H84.333 c-5.12,0-8.533-3.413-8.533-8.533V24.6c0-5.12,3.413-8.533,8.533-8.533h341.333c5.12,0,8.533,3.413,8.533,8.533V485.4z"></path> <path d="M391.533,220.867H118.467c-5.12,0-8.533,3.413-8.533,8.533s3.413,8.533,8.533,8.533h273.067 c5.12,0,8.533-3.413,8.533-8.533S396.653,220.867,391.533,220.867z"></path> <path d="M391.533,340.333H118.467c-5.12,0-8.533,3.413-8.533,8.533s3.413,8.533,8.533,8.533h273.067 c5.12,0,8.533-3.413,8.533-8.533S396.653,340.333,391.533,340.333z"></path> <path d="M306.2,263.533h-42.667c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533H306.2 c5.12,0,8.533-3.413,8.533-8.533C314.733,266.947,311.32,263.533,306.2,263.533z"></path> <path d="M348.867,280.6c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-8.533c-5.12,0-8.533,3.413-8.533,8.533 c0,5.12,3.413,8.533,8.533,8.533H348.867z"></path> <path d="M263.533,314.733h25.6c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-25.6c-5.12,0-8.533,3.413-8.533,8.533 S258.413,314.733,263.533,314.733z"></path> <path d="M314.733,306.2c0,5.12,3.413,8.533,8.533,8.533H383c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-59.733 C318.147,297.667,314.733,301.08,314.733,306.2z"></path> <path d="M118.467,280.6h42.667c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-42.667 c-5.12,0-8.533,3.413-8.533,8.533C109.933,277.187,113.347,280.6,118.467,280.6z"></path> <path d="M203.8,280.6c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-8.533c-5.12,0-8.533,3.413-8.533,8.533 c0,5.12,3.413,8.533,8.533,8.533H203.8z"></path> <path d="M297.667,391.533c0-5.12-3.413-8.533-8.533-8.533h-25.6c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533 h25.6C294.253,400.067,297.667,396.653,297.667,391.533z"></path> <path d="M383,383h-59.733c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533H383c5.12,0,8.533-3.413,8.533-8.533 C391.533,386.413,388.12,383,383,383z"></path> <path d="M323.267,417.133h-25.6c-5.12,0-8.533,3.413-8.533,8.533s3.413,8.533,8.533,8.533h25.6c5.12,0,8.533-3.413,8.533-8.533 S328.387,417.133,323.267,417.133z"></path> <path d="M383,417.133h-25.6c-5.12,0-8.533,3.413-8.533,8.533s3.413,8.533,8.533,8.533H383c5.12,0,8.533-3.413,8.533-8.533 S388.12,417.133,383,417.133z"></path> <path d="M161.133,383h-42.667c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533h42.667 c5.12,0,8.533-3.413,8.533-8.533C169.667,386.413,166.253,383,161.133,383z"></path> <path d="M203.8,383h-8.533c-5.12,0-8.533,3.413-8.533,8.533c0,5.12,3.413,8.533,8.533,8.533h8.533 c5.12,0,8.533-3.413,8.533-8.533C212.333,386.413,208.92,383,203.8,383z"></path> <path d="M118.467,84.333H178.2c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-59.733 c-5.12,0-8.533,3.413-8.533,8.533S113.347,84.333,118.467,84.333z"></path> <path d="M118.467,152.6H178.2c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-59.733 c-5.12,0-8.533,3.413-8.533,8.533C109.933,149.187,113.347,152.6,118.467,152.6z"></path> <path d="M212.333,84.333h8.533c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-8.533c-5.12,0-8.533,3.413-8.533,8.533 S207.213,84.333,212.333,84.333z"></path> <path d="M212.333,118.467H255c5.12,0,8.533-3.413,8.533-8.533S260.12,101.4,255,101.4h-42.667c-5.12,0-8.533,3.413-8.533,8.533 S207.213,118.467,212.333,118.467z"></path> <path d="M212.333,152.6h8.533c5.12,0,8.533-3.413,8.533-8.533c0-5.12-3.413-8.533-8.533-8.533h-8.533 c-5.12,0-8.533,3.413-8.533,8.533C203.8,149.187,207.213,152.6,212.333,152.6z"></path> <path d="M212.333,186.733H255c5.12,0,8.533-3.413,8.533-8.533s-3.413-8.533-8.533-8.533h-42.667c-5.12,0-8.533,3.413-8.533,8.533 S207.213,186.733,212.333,186.733z"></path> </g> </g> </g> </g></svg>
              </div>
              <div class="text-center mt-2">
                Opret gratis profil
              </div>
            </div>
    
            <!-- Image 2 -->
            <div class="py-8 md:relative flex flex-col items-center">
              <div class="text-center mt-2 text-2xl">
                Step 2
              </div>
              <div class="max-w-full h-auto rounded-lg overflow-hidden flex justify-center items-center">
               <svg height="140px" width="140px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 392.663 392.663" xml:space="preserve" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <polygon style="fill:#bfdbfe;" points="167.758,310.432 147.588,350.901 244.945,350.901 224.776,310.432 "></polygon> <path style="fill:#FFFFFF;" d="M360.986,41.762H31.547c-5.301,0-9.632,4.331-9.632,9.632v227.556c0,5.301,4.331,9.632,9.632,9.632 h329.568c5.301,0,9.632-4.331,9.632-9.632V51.394C370.747,46.093,366.416,41.762,360.986,41.762z"></path> <path style="fill:#000000;" d="M360.986,19.911H31.547C14.158,19.911,0,34.069,0,51.459v227.556 c0,17.39,14.158,31.547,31.547,31.547h111.903l-23.208,46.416c-3.62,7.24,1.616,15.774,9.762,15.774h132.655 c8.145,0,13.382-8.469,9.762-15.774l-23.208-46.416h111.903c17.39,0,31.547-14.158,31.547-31.547V51.459 C392.533,34.069,378.376,19.911,360.986,19.911z M370.747,279.014c0,5.301-4.331,9.632-9.632,9.632H31.547 c-5.301,0-9.632-4.331-9.632-9.632V51.459c0-5.301,4.331-9.632,9.632-9.632h329.568c5.301,0,9.632,4.331,9.632,9.632V279.014z M147.588,350.901l20.17-40.404h57.018l20.17,40.404H147.588z"></path> <path style="fill:#bfdbfe;" d="M338.036,63.547H54.562c-6.012,0-10.925,4.848-10.925,10.925v1.422h25.277 c6.012,0,10.925,4.848,10.925,10.925c0,6.077-4.848,10.925-10.925,10.925H43.636v18.941h1.616c6.012,0,10.925,4.848,10.925,10.925 c0,6.012-4.848,10.925-10.796,10.925h-1.681v117.592c0,6.012,4.848,10.925,10.925,10.925h283.539 c6.012,0,10.925-4.848,10.925-10.925V74.473C349.026,68.461,344.048,63.547,338.036,63.547z"></path> <circle style="fill:#FFFFFF;" cx="188.38" cy="164.978" r="27.927"></circle> <g> <path style="fill:#000000;" d="M230.529,191.03c4.719-7.564,7.434-16.485,7.434-26.053c0-27.345-22.174-49.519-49.519-49.519 s-49.519,22.174-49.519,49.519c0,27.345,22.174,49.519,49.519,49.519c9.891,0,19.071-2.909,26.828-7.952l41.051,41.051 c4.267,4.267,11.119,4.267,15.451,0c4.267-4.202,4.267-11.055,0-15.386L230.529,191.03z M188.38,192.84 c-15.386,0-27.927-12.412-27.927-27.927c0-15.386,12.541-27.927,27.927-27.927s27.927,12.541,27.927,27.927 C216.307,180.364,203.766,192.84,188.38,192.84z"></path> <path style="fill:#000000;" d="M74.667,136.598h27.604v43.636c0,11.766-7.758,13.576-10.667,13.576 c-6.077,0-11.96-3.038-17.519-9.051l-10.796,14.933c8.339,8.598,18.101,12.929,29.285,12.929c8.986,0,30.578-3.297,30.578-33.164 V118.82h-48.42v17.778H74.667z"></path> <path style="fill:#000000;" d="M335.386,186.053c-0.259-19.523-19.006-22.497-19.006-22.497s13.77-3.232,13.77-20.17 c0-26.893-32.905-24.63-32.905-24.63h-36.331v93.22h40.792C337.002,213.01,335.386,186.053,335.386,186.053z M281.665,136.339 h0.065h9.956c6.723,0.323,17.131-0.84,16.937,10.214c0,5.43-1.228,9.891-17.067,9.891h-9.891L281.665,136.339L281.665,136.339z M295.952,194.327h-14.287v-21.463h12.283c8.275,0.388,20.105-0.453,19.846,10.602C313.859,187.733,313.277,194.65,295.952,194.327 z"></path> </g> </g></svg>
              </div>
              <div class="text-center mt-2">
                <p>Bliv opdaget af virksomeder og modtag jobtilbud der matcher dine kompentencer</p>
              </div>
            </div>
    
            <!-- Image 3 -->
            <div class="py-8 md:relative flex flex-col items-center">
              <div class="text-center mt-2 text-2xl">
                Step 3
              </div>
              <div class="max-w-full h-auto rounded-lg overflow-hidden flex justify-center items-center">
                <svg height="141px" width="141px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 495.62 495.62" xml:space="preserve" fill="#000000" transform="rotate(0)matrix(1, 0, 0, 1, 0, 0)"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <path style="fill:#000000;" d="M495.622,113.089v150.03c0,0-32.11,6.326-38.725,7.158c-6.594,0.83-27.316,7.521-42.334-6.914 c-23.16-22.197-105.447-104.03-105.447-104.03s-14.188-13.922-36.969-1.89c-20.912,11.022-51.911,27.175-64.859,33.465 c-24.477,13.028-44.764-7.642-44.764-23.387c0-12.213,7.621-20.502,18.515-26.598c29.524-17.898,91.752-52.827,117.67-66.598 c15.754-8.379,27.105-9.097,48.734,9.124c26.638,22.403,50.344,42.824,50.344,42.824s7.732,6.453,20.063,3.854 C448.13,123.725,495.622,113.089,495.622,113.089z M168.098,367.3c3.985-10.238,2.653-21.689-4.987-29.545 c-6.865-7.027-16.888-8.879-26.445-6.689c2.673-9.479,1.197-19.568-5.705-26.688c-6.886-7.009-16.89-8.898-26.446-6.688 c2.653-9.465,1.181-19.553-5.725-26.652c-10.814-11.092-29.519-10.616-41.807,1.097c-12.223,11.729-20.053,32.979-9.144,45.487 c10.891,12.445,23.405,4.873,32.945,2.699c-2.654,9.465-10.606,18.269-0.813,30.658c9.784,12.395,23.404,4.875,32.954,2.721 c-2.663,9.429-10.268,19.117-0.851,30.604c9.502,11.522,25.065,5.383,35.344,2.19c-3.967,10.199-12.458,21.193-1.549,33.513 c10.892,12.409,36.063,6.668,48.358-5.063c12.262-11.729,13.439-30.318,2.654-41.445 C189.435,365.865,178.335,364.089,168.098,367.3z M392.442,289.246c-88.88-88.881-47.075-47.058-94.906-94.992 c0,0-14.375-14.311-33.321-5.998c-13.3,5.828-30.423,13.771-43.307,19.835c-14.158,7.424-24.347,9.722-29.131,9.69 c-27.37-0.179-49.576-22.178-49.576-49.521c0-17.738,9.417-33.181,23.462-41.947c19.75-13.667,65.21-37.847,65.21-37.847 s-13.849-17.549-44.187-17.549c-30.329,0-93.695,41.512-93.695,41.512s-17.976,11.514-43.601,1.143L0,96.373V268.05 c0,0,14.103,4.082,26.775,9.258c2.862-8.162,7.48-15.699,13.886-21.924c21.023-20.024,55.869-20.232,74.996-0.537 c5.762,5.987,9.783,13.129,11.835,21.024c7.707,2.379,14.688,6.593,20.298,12.373c5.779,5.947,9.785,13.129,11.854,20.984 c7.698,2.381,14.669,6.611,20.298,12.395c6.339,6.537,10.562,14.433,12.534,22.988c8.047,2.344,15.319,6.705,21.176,12.693 c11.495,11.807,15.575,27.826,13.103,43.278c0.02,0,0.058,0,0.076,0.035c0.188,0.246,7.122,7.976,11.446,12.336 c8.474,8.482,22.311,8.482,30.811,0c8.444-8.479,8.481-22.289,0-30.811c-0.304-0.303-30.572-31.963-28.136-34.418 c2.418-2.438,40.981,37.688,41.699,38.422c8.463,8.465,22.291,8.465,30.792,0c8.481-8.479,8.463-22.289,0-30.791 c-0.416-0.396-2.152-2.059-2.796-2.721c0,0-38.234-34.06-35.324-36.97c2.946-2.928,50.438,41.392,50.515,41.392 c8.537,7.688,21.687,7.631,29.9-0.586c7.991-7.99,8.162-20.629,1.078-29.146c-0.15-0.453-36.194-38.121-33.381-40.955 c2.854-2.871,38.519,33.853,38.594,33.929c8.444,8.463,22.291,8.463,30.792,0c8.463-8.464,8.463-22.291,0-30.83 C392.706,289.396,392.555,289.32,392.442,289.246z"></path> </g> </g></svg>
              </div>
              <div class="text-center mt-2">
                <p>Start dit nye studie job</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    <div class="min-h-screen bg-blue-200 flex-1 flex justify-center items-center">
      <div class="container mx-auto px-4 py-16">
        <h1 class="text-5xl font-mono font-medium">Virksomhed</h1>

        <div class="font-mono max-w-3xl">
          <h1 class="py-8 text-xl font-bold">StudentSeeker - Din Studenter Service</h1>
          <p>Velkommen til tudentSeeker, skabt af studerende for studerende! Vi forstår udfordringerne ved studielivet, og vores mål er at gøre det lettere og mere givende for dig.</p>
          <p>StudentSeeker tilbyder personlig studievejledning, hvor erfarne studerende deler indsigt om fagvalg, studieteknikker og karriereveje. Vi skaber et fællesskab, hvor studerende støtter hinanden.</p>
          <p>Få eksklusive studierabatter på relevante materialer, software og nødvendigheder. Vi stræber efter at lette økonomien for studerende.</p>
          <p>STUDENTSEEKER er mere end en service; det er en bevægelse. Deltag i vores fællesskab, del dine erfaringer, og skab en mere støttende studiekultur.</p>
          <p>Tilmeld dig STUDENTSEEKER i dag for at gøre dine studieår problemfri og meningsfulde!</p>
          <div class="py-8">
            <button class="text-2xl px-4 font-bold py-0.5 border-4 border-indigo-400 bg-white rounded">
              <a data-sveltekit-preload-data="tap" href="/register-virksomhed">Tilmeld dig nu!</a>
            </button>
          </div>
        </div>
      </div>
    </div>


  </section>
  
  <section id="section3" class="bg-indigo-400 relative overflow-hidden">
    
    <svg class="hidden lg:block absolute z-0" id="eO50DlaxgtY1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 600 600" shape-rendering="geometricPrecision" text-rendering="geometricPrecision"><path d="M405.317499,229.220442C445.923123,14.921882,554.76125,37.548447,599.999998,40.268454v411.977285C443.89038,401.045684,396.2937,318.055174,405.317499,229.220442Z" transform="translate(.000002 0.000002)" opacity="0.6" fill="none" stroke="#bfdbfe" stroke-width="1.2"/><path d="M417.707796,187.919463Q242.178627,328.342798,496.179659,56.788849q39.235931,365.51368,39.235931,366.546205c0,1.032525,57.821374-375.838926-117.707794-235.415591Z" transform="translate(.000001 0)" opacity="0.6" fill="none" stroke="#bfdbfe" stroke-width="1.2"/><path d="M527.155395,49.561177c-24.997252,0-.456559-37.217919,23.748064,2.065049c20.000999,32.460683,9.437074,81.717465,34.073309,34.073309q30.418916-58.827316-49.561178,196.179659-97.681724,11.35777-85.29143,13.422819c12.390294,2.065049-63.392101-71.244193,10.949664-.000001q74.341765,71.244192,66.081571-245.740836q59.886422,361.383583,57.821373,361.383583t-167.268973-92.927207" transform="translate(.000002 0.000001)" opacity="0.6" fill="none" stroke="#bfdbfe" stroke-width="1.2"/><path d="M450.124162,142.488384q-32.416365,163.138875-39.644038,164.171399l182.75684-66.597832Q482.540527,-20.650493,450.124162,142.488384Z" transform="translate(0 0.000002)" opacity="0.6" fill="none" stroke="#bfdbfe" stroke-width="1.2"/><path d="M378.471864,254.001033q-92.927207,85.699535,135.260712,80.536912L593.236963,51.626226Q471.39907,168.301497,378.471864,254.001033Z" transform="translate(.000001 0.000001)" opacity="0.6" fill="none" stroke="#bfdbfe" stroke-width="1.2"/><path d="M588.322695,355.188436L470.366546,99.122354L496.17966,377.903975l92.143035-22.715539Z" opacity="0.6" fill="none" stroke="#bfdbfe" stroke-width="1.2"/><path d="M593.236964,423.335054L461.073826,240.061953L593.236964,136.293237v287.041817Z" opacity="0.6" fill="none" stroke="#bfdbfe" stroke-width="1.2"/></svg>
    <div class="container mx-auto py-16 text-center relative z-10">
      <div class="w-1/2 mx-auto">
        <h1 class="font-bold">
          Eveniet, doloremque aliquid!
        </h1>
        <p class="py-4">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus distinctio, 
          pariatur quos, doloribus cupiditate quo tempora sit nemo quod nam odit assumenda 
          consequuntur unde ducimus delectus repellendus qui necessitatibus sunt.
        </p>
    </div>
    <div class="w-1/2 mx-auto">
      <h1 class="font-bold">
        Eveniet, doloremque aliquid!
      </h1>
      <p class="py-4">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus distinctio, 
        pariatur quos, doloribus cupiditate quo tempora sit nemo quod nam odit assumenda 
        consequuntur unde ducimus delectus repellendus qui necessitatibus sunt.
      </p>
  </div>
  
  <div class="w-1/2 mx-auto">
    <h1 class="font-bold">
      Eveniet, doloremque aliquid!
    </h1>
    <p class="py-4">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus distinctio, 
      pariatur quos, doloribus cupiditate quo tempora sit nemo quod nam odit assumenda 
      consequuntur unde ducimus delectus repellendus qui necessitatibus sunt.
      
    </p>
</div>
<div class="w-1/2 mx-auto">
  <h1 class="font-bold">
    Eveniet, doloremque aliquid!
  </h1>
  <p class="py-4">
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus distinctio, 
    pariatur quos, doloribus cupiditate quo tempora sit nemo quod nam odit assumenda 
    consequuntur unde ducimus delectus repellendus qui necessitatibus sunt.
  </p>
</div>
<div class="w-1/2 mx-auto">
  <h1 class="font-bold">
    Eveniet, doloremque aliquid!
  </h1>
  <p class="py-4">
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus distinctio, 
    pariatur quos, doloribus cupiditate quo tempora sit nemo quod nam odit assumenda 
    consequuntur unde ducimus delectus repellendus qui necessitatibus sunt.
  </p>
</div>
<div class="w-1/2 mx-auto">
<h1 class="font-bold">
  Eveniet, doloremque aliquid!
</h1>
<p class="py-4">
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus distinctio, 
  pariatur quos, doloribus cupiditate quo tempora sit nemo quod nam odit assumenda 
  consequuntur unde ducimus delectus repellendus qui necessitatibus sunt.
</p>
</div>
  <div class="w-1/2 mx-auto">
    <h1 class="font-bold">
      Eveniet, doloremque aliquid!
    </h1>
    <p class="py-4">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus distinctio, 
      pariatur quos, doloribus cupiditate quo tempora sit nemo quod nam odit assumenda 
      consequuntur unde ducimus delectus repellendus qui necessitatibus sunt.
    </p>
</div>
</div>
</section>

</body>
