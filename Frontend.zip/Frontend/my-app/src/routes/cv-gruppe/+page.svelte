<script>
    import { user } from '$lib/index';
    import { goto } from '$app/navigation';
    
  
    let userInfo;
    let firstName = '';
    let middleName = '';
    let lastName = '';
    let birthday = '';
    let education = '';
    let occupation = '';
  
    // Subscribe to the user store
    $: userInfo = $user;
  
    const addInfo = () => {
      user.update((userInfo) => {
        const updatedUserInfo = { ...userInfo, firstName, middleName, lastName, birthday, education, occupation };
        console.log(updatedUserInfo);
        goto('./usertags');
        return updatedUserInfo;
      });
    };
  </script>
    
  
  <body>
    <header>
      <div class="bg-white text-blue-500">
        <div class="container mx-auto flex justify-between items-center py-4">
          <div>
            <button class="font-mono font-bold text-5xl px-4 rounded">
              <a href="/">StudentSeeker</a>
            </button>
          </div>
        </div>
      </div>
    </header>

    <div class="container mx-auto h-screen ">

        <div class="container mx-auto text-black">
            <h1 class="text-center text-3xl font-mono font-bold"> Let get started with your account {userInfo.username}!</h1>
            <div class="max-w-md mx-auto bg-white p-8 shadow-md rounded-md mt-8">
                <h2 class="text-2xl font-semibold mb-4">Personal Information</h2>
              
                <!-- Birthday Input -->
              <div class="mb-4">
                <label for="birthday" class="block text-sm font-medium text-gray-600">CPR Nummer</label>
                <input bind:value={birthday} type="text" id="birthday" name="birthday" placeholder="dd/mm/yy/tal" class="mt-1 p-2 w-full border rounded-md">
              </div>
              
                <!-- First Name Input -->
                <div class="mb-4">
                  <label for="firstName" class="block text-sm font-medium text-gray-600">First Name</label>
                  <input bind:value={firstName} type="text" placeholder="Required " id="firstName" name="firstName" class="mt-1 p-2 w-full border rounded-md">
                </div>
              
                <!-- Middle Name Input -->
                <div class="mb-4">
                  <label for="middleName" class="block text-sm font-medium text-gray-600">Middle Name</label>
                  <input bind:value={middleName} type="text" id="middleName" placeholder="Optional" name="middleName" class="mt-1 p-2 w-full border rounded-md">
                </div>
              
                <!-- Last Name Input -->
                <div class="mb-4">
                  <label for="lastName" class="block text-sm font-medium text-gray-600">Last Name</label>
                  <input bind:value={lastName} type="text" id="lastName" placeholder="Required " name="lastName" class="mt-1 p-2 w-full border rounded-md">
                </div>
              
                <!-- Education Input -->
                <div class="mb-4">
                  <label for="education" class="block text-sm font-medium text-gray-600">Education</label>
                  <input bind:value={education} type="text" id="education" placeholder="Required "name="education" class="mt-1 p-2 w-full border rounded-md">
                </div>
              
                <!-- Current Occupation Input -->
                <div class="mb-4">
                  <label for="occupation" class="block text-sm font-medium text-gray-600">Current Occupation</label>
                  <input bind:value={occupation} type="text" id="occupation" placeholder="Required " name="occupation" class="mt-1 p-2 w-full border rounded-md">
                </div>
              
                <!-- Submit Button -->
                    <button on:click={addInfo} type="submit" class="bg-blue-500 text-white p-2 rounded-md w-full hover:bg-blue-600">
                        Next step
                    </button>
                
            </div>

    </div>
  
  
  </body>
  