<script>
    import { virksomhed } from '$lib/index';
    import { goto } from '$app/navigation';


    let VirksomhedInfo;
    let VirksomhedNavn = '';
    let Betaling = '';
    let VirksomhedBranche = '';
  
    // Subscribe to the user store
   VirksomhedInfo = $virksomhed;

  
    const addInfo = () => {
      virksomhed.update((virksomhed) => {
        const updatedVirksomhed = { ...virksomhed, VirksomhedNavn, Betaling, VirksomhedBranche };
        goto('./main-Virksomhed');
        return updatedVirksomhed;
      });
    };
  </script>
    
  
  <body>
    <header>
      <div class="bg-white text-blue-500">
        <div class="container mx-auto flex justify-between items-center py-4">
          <div>
            <button class="font-mono font-bold text-5xl px-4 rounded">
              <a href="/">StudentSeeker</a>
            </button>
          </div>
        </div>
      </div>
    </header>

    <div class="container mx-auto h-screen ">

        <div class="container mx-auto text-black">
            <h1 class="text-center text-3xl font-mono font-bold"> Let get started with your account {VirksomhedInfo.usernamevirksomhed}!</h1>
            <div class="max-w-md mx-auto bg-white p-8 shadow-md rounded-md mt-8">
                <h2 class="text-2xl font-semibold mb-4">Vigtige Information</h2>
              
                <!-- Birthday Input -->
              <div class="mb-4">
                <label for="virksomhedNavn" class="block text-sm font-medium text-gray-600">Virksomheds Navn</label>
                <input bind:value={VirksomhedNavn} type="text" id="virksomhedNavn" name="virksomhedNavn" placeholder="Required" class="mt-1 p-2 w-full border rounded-md">
              </div>
              
                <!-- Current Occupation Input -->
                <div class="mb-4">
                  <label for="Virksomhedsbranche" class="block text-sm font-medium text-gray-600">Virksomheds branche</label>
                  <input bind:value={Betaling} type="text" id="Virksomhedsbranche" placeholder="Required " name="Virksomhedsbranche" class="mt-1 p-2 w-full border rounded-md">
                </div>

                  <!-- Current credit card Input -->
                  <div class="mb-4">
                    <label for="Betaling" class="block text-sm font-medium text-gray-600">Betaling</label>
                    <input bind:value={VirksomhedBranche} type="text" id="Betaling" placeholder="Required " name="Betaling" class="mt-1 p-2 w-full border rounded-md">
                  </div>
              
                <!-- Submit Button -->
                
                    <button on:click={addInfo} type="submit" class="bg-blue-500 text-white p-2 rounded-md w-full hover:bg-blue-600">
                        Next step
                    </button>
            </div>

    </div>
  
  
  </body>
  