

<script>
import { virksomhed } from '$lib/index';
import { JobOpslag } from '$lib/index';
import { goto } from '$app/navigation';
import { onMount } from 'svelte';


const virksomhedInfo = $virksomhed;
let JobINFO = $JobOpslag;
let activeButton = null;

console.log(JobINFO);
console.log(virksomhedInfo);
let selectedOption = "";
let textInput1 = '';
let textInput2 = '';
let textInput3 = '';
if (virksomhedInfo.job_opslag) {
  const jobOp = virksomhedInfo.job_opslag[JobINFO];
  if (jobOp) {
    selectedOption = jobOp.selectedOption || '';
    textInput1 = jobOp.textInput1 || '';
    textInput2 = jobOp.textInput2 || '';
    textInput3 = jobOp.textInput3 || '';

  }};

onMount(() => {
if (virksomhedInfo.job_opslag) {
  let jobOp = virksomhedInfo.job_opslag[JobINFO];
  if (jobOp) {
    selectedOption = jobOp.selectedOption || '';
    textInput1 = jobOp.textInput1 || '';
    textInput2 = jobOp.textInput2 || '';
    textInput3 = jobOp.textInput3 || '';
    const changecoloronbutton = document.getElementById(selectedOption);
    handleClick(changecoloronbutton, true);
  }
}
 });

 
function handleClick(button, first) {

if (activeButton === button) {
  // If the same button is clicked again, deactivate it
  button.classList.remove('bg-blue-200');
  activeButton = null;
} else {
  // Deactivate the currently active button
  if (activeButton) {
    activeButton.classList.remove('bg-blue-200');
  }
  // Activate the clicked button
  button.classList.add('bg-blue-200');
  activeButton = button;
  if (first == false) {
    selectedOption = event.target.getAttribute('id');}
}
}

const saveJOB = () => {
  
  virksomhed.update((virksomhed) => {
    JobINFO = $JobOpslag;
    virksomhed.job_opslag[JobINFO] = { textInput1, selectedOption, textInput2, textInput3 };
    console.log(virksomhed.job_opslag[JobINFO]);
    console.log(JobINFO);
    const updatedVirksomhed = { 
      ...virksomhed
    };
    goto('./main-Virksomhed');
    console.log(updatedVirksomhed);
    return updatedVirksomhed;
  });
};



function scrollIntoView(event) {
    event.preventDefault(); // Prevent the default behavior of the anchor tag
    const targetId = event.target.getAttribute('href');
    const targetSection = document.querySelector(targetId);
    if (targetSection) {
      targetSection.scrollIntoView({
        behavior: 'smooth'
      });
    }
  }
 
const profileload = () => {
  event.preventDefault(); 
  goto('./cv-virksomhed');
}


</script>


<header>
     
  <div class="bg-indigo-400 text-white py-8">
    <div class=" lg:flex justify-between items-center container mx-auto gap-4">
      <div class="flex items-center">
        <button class="font-mono font-bold text-5xl px-4 rounded">
          <a href="/">StudentSeeker</a>
        </button>
        </div>
        <div class="border-t-2 border-white lg:block "></div>
        <nav class="flex flex-col items-center lg:block">
          <a class="py-4 font-mono text-white font-bold text-3xl lg:text-2xl lg:px-3 rounded" href="#section3" on:click={profileload}>Profil</a>
          <button class=" not-clickable border-l-2 border-white h-5 hidden lg:inline"></button>
          <a class=" py-4 font-mono text-white font-bold text-3xl lg:text-2xl lg:px-2 rounded" href="#section4" on:click|preventDefault={scrollIntoView}>Kontakt</a>
         
        </nav>
      </div>
    </div>
</header>

<body class="flex flex-col min-h-screen">
  <div class="flex-grow">
     <div class="bg-gray-200 px-8 shadow-xl rounded-md mt-8 ">
         <h2 class="text-2xl font-semibold mb-4">Job Opslag</h2>
       
       <div class="mb-8 py-8">
         <label for="birthday" class="block text-lg font-medium text-gray-600">Tittle</label>
         <textarea bind:value={textInput1} placeholder="Required" id="Tittle" name="Tittle" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" rows="2"></textarea>
       </div>
 
         <div class="mb-8 py-8">
           <label for="Beskrivelse" class="text-lg block font-medium text-gray-600">Job Beskrivelse</label>
           <textarea bind:value={textInput2} placeholder="Required " id="Beskrivelse" name="Beskrivelse" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" rows="4"></textarea>
         </div>

         <div class="mb-8 py-8">
           <label for="buttons" class="block text-sm font-medium text-gray-600">Button</label>
           <div class="w-full flex gap-4">
             <button class="flex-1 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-2 rounded focus:outline-none focus:shadow-outline" id="1" on:click={() => handleClick(event.target, false)}>Button 1</button>
             <button class="flex-1 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-2 rounded focus:outline-none focus:shadow-outline" id="2" on:click={() => handleClick(event.target, false)}>Button 2</button>
             <button class="flex-1 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-2 rounded focus:outline-none focus:shadow-outline" id="3"  on:click={() => handleClick(event.target, false)}>Button 3</button>
             <button class="flex-1 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-2 rounded focus:outline-none focus:shadow-outline" id="4"  on:click={() => handleClick(event.target, false)}>Button 4</button>
             <button class="flex-1 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-2 rounded focus:outline-none focus:shadow-outline" id="5"  on:click={() => handleClick(event.target, false)}>Button 5</button>
           </div>
         </div>
     
         <div class="mb-8 py-8">
           <label for="Order" class="block text-lg font-medium text-gray-600">Række Følge</label>
           <textarea bind:value={textInput3} placeholder="Required " id="Order"  name="Order" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" rows="4"></textarea>
           
         </div>
         <div class="flex justify-center py-4   ">
          <button on:click={saveJOB} type="submit" class="bg-blue-500 text-white p-2 rounded-md w-1/2 font-bold hover:bg-blue-600">
              Rediger JobOpslag
          </button>
       </div>
     </div>
  </div>
</body>

