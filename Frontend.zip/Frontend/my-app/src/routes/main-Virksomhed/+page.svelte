
<script>
import { virksomhed } from '$lib/index';
import { JobOpslag } from '$lib/index';
import { goto } from '$app/navigation';

let i;

let jobs = [];

const virksomhedInfo = $virksomhed;

if (virksomhedInfo && virksomhedInfo.job_opslag) {
  i = virksomhedInfo.job_opslag.length -1;
  console.log(virksomhedInfo);
}
else {
  i = 0;
}

if (virksomhedInfo && virksomhedInfo.job_opslag && virksomhedInfo.job_opslag.length > i) {
  for (i in virksomhedInfo.job_opslag) {
    let title = virksomhedInfo.job_opslag[i].textInput1;
    let Beskrivelse = virksomhedInfo.job_opslag[i].textInput2.split(" ");
    let buttonpressed = virksomhedInfo.job_opslag[i].selectedOption;
    let Række = virksomhedInfo.job_opslag[i].textInput3.split(" ");
  jobs.push({
      id: i,
      title: title,
      Beskrivelse: Beskrivelse.slice(0, 8).join(" "),
      button: buttonpressed,
      Række: Række.slice(0, 8).join(" ")
    })};
    
  }
else {
 jobs = [
    {title: "Igen nuværende", Beskrivelse: "Jobopslag",button: "Lav et ", Række: "nu!" },]}


function scrollIntoView(event) {
    event.preventDefault(); // Prevent the default behavior of the anchor tag
    const targetId = event.target.getAttribute('href');
    const targetSection = document.querySelector(targetId);
    if (targetSection) {
      targetSection.scrollIntoView({
        behavior: 'smooth'
      });
    }
  }

  const RedigerJob = (id) => { 
    let buttonValue = id;
    console.log(buttonValue);
    JobOpslag.set(buttonValue);
    goto('./edit-job');
}
 
const profileload = () => {
  event.preventDefault(); 
  goto('./cv-virksomhed');

}
</script>

<header>
     
  <div class="bg-indigo-400 text-white py-8">
    <div class=" lg:flex justify-between items-center container mx-auto gap-4">
      <div class="flex items-center">
        <button class="font-mono font-bold text-5xl px-4 rounded">
          <a href="/">StudentSeeker</a>
        </button>
        </div>
        <div class="border-t-2 border-white lg:hidden "></div>
        <nav class="flex flex-col items-center lg:block">
          <a class="py-4 font-mono text-white font-bold text-3xl lg:text-2xl lg:px-3 rounded" href="#section3" on:click={profileload}>Profil</a>
          <button class=" not-clickable border-l-2 border-white h-5 hidden lg:inline"></button>
          <a class=" py-4 font-mono text-white font-bold text-3xl lg:text-2xl lg:px-2 rounded" href="#section4" on:click|preventDefault={scrollIntoView}>Kontakt</a>
         
        </nav>
      </div>
    </div>
</header>

<body>
  <div class="flex h-screen">
    <div class="w-2/3 p-4">
      <div class="overflow-auto h-full">
        <table class="w-full table-auto">
          <thead>
            <tr>
              <th class="px-4 py-2 text-center">{virksomhedInfo.VirksomhedNavn} Job Opslag </th>
            </tr>
          </thead>
          <tbody>
            {#each jobs as job}
              <tr>
                <td class="border px-4 py-2">{job.title}</td>
                <td class="border px-4 py-2">{job.Beskrivelse}</td> 
                <td class="border px-4 py-2">{job.button}</td>
                <td class="border px-4 py-2">{job.Række}</td>
                <td><button class="border px-4 py-2" on:click|preventDefault={RedigerJob(job.id)}>Rediger Opslag</button></td>
              </tr>
            {/each}
          </tbody>
        </table>
      </div>
    </div>
  

    <div class="w-2/3 flex justify-center items-center">
      <div class="">
        <div class="py-16 px-16 border-8 border-black rounded-lg">
        <div class="flex justify-center items-center">
          <a href="/Newjob">
          <button class="bg-indigo-400 hover:bg-indigo-600 text-white font-bold py-6 px-8 rounded-full">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
            </svg>
          </button>
        </a>
        </div>
      </div>
        <p class="text-center font-mono font-bold py-2"> Lav et nyt job opslag</p>
      </div>
    </div>
  </div>
</body>