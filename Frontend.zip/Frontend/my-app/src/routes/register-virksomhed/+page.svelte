

<script>
  import { virksomhed } from '$lib/index';
  import { goto } from '$app/navigation';
  let usernamevirksomhed = '';
  let passwordvirksomhed = '';
  let emailvirksomhed = '';
  let loginEmailVirksomhed = '';
  let loginPasswordVirksomhed = '';

  const register = () => {
    event.preventDefault(); 

    if (usernamevirksomhed != '' && passwordvirksomhed != '') {
    const Virksomhedinfo = { usernamevirksomhed, emailvirksomhed, passwordvirksomhed };
    virksomhed.set(Virksomhedinfo);
    goto('./cv-virksomhed');
      }
    else {
      console.log('JOOO PUT INFO IN')
    }
  }

  const logincheck = () => {
    if (loginEmailVirksomhed == 'vincentmemphis@gmail.com' & loginPasswordVirksomhed == 'Vv000')  {
      console.log('nice')
  }
}

</script>

<body>
  
  <header>
  
    <div class="bg-white text-blue-500">
      <div class="container mx-auto flex justify-between items-center py-4">
        <div>
          <button class=" font-mono  font-bold text-5xl px-4 rounded">
              <a href="/" >StudentSeeker</a>
            </button>
        </div>
      </div>
  </div>



  </header>

  <div class="container mx-auto h-screen">
  <h1 class="text-center text-3xl font-bold"> Tilmeld din Virksomhed nu!</h1>
    <div class="container mx-auto flex justify-center items-center h-screen">
      
        <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
          <h1 class="text-2xl font-bold mb-6">Register or Login</h1>
      
          <form>
           
            <div class="mb-4">
              <label for="usernamevirksomhed" class="block text-sm font-medium text-gray-600">Username</label>
              <input bind:value={usernamevirksomhed} type="text" autocomplete="given-name" id="usernamevirksomhed" name="usernamevirksomhed" class="mt-1 p-2 w-full border rounded-md">
            </div>
      
            <div class="mb-4">
              <label for="emailvirksomhed" class="block text-sm font-medium text-gray-600">Email</label>
              <input bind:value={emailvirksomhed} type="emailvirksomhed" autocomplete="given-name" id="emailvirksomhed" name="emailvirksomhed" class="mt-1 p-2 w-full border rounded-md">
            </div>
      
            <div class="mb-4">
              <label for="passwordvirksomhed" class="block text-sm font-medium text-gray-600">Password</label>
              <input bind:value={passwordvirksomhed} type="passwordvirksomhed" autocomplete="given-name" id="passwordvirksomhed" name="passwordvirksomhed" class="mt-1 p-2 w-full border rounded-md">
            </div>
            
            <button on:click={register}  type="submit" class="bg-blue-500 text-white p-2 rounded-md w-full hover:bg-blue-600">
                Register
            </button>
          
          </form>
      
          
          <div class="flex items-center my-6">
            <div class="border-t border-gray-400 flex-1"></div>
            <span class="mx-2 text-gray-600">or</span>
            <div class="border-t border-gray-400 flex-1"></div>
          </div>
      
          
          <form>
            <div class="mb-4">
              <label for="loginEmailVirksomhed" class="block text-sm font-medium text-gray-600">Email</label>
              <input bind:value= {loginEmailVirksomhed} type="email" autocomplete="given-name" id="loginEmailVirksomhed" name="loginEmailVirksomhed" class="mt-1 p-2 w-full border rounded-md">
            </div>
      
            <div class="mb-4">
              <label for="loginPasswordVirksomhed" class="block text-sm font-medium text-gray-600">Password</label>
              <input bind:value= {loginPasswordVirksomhed} type="password" autocomplete="given-name" id="loginPasswordVirksomhed" name="loginPasswordVirksomhed" class="mt-1 p-2 w-full border rounded-md">
            </div>
            
            <button on:click={logincheck} type="submit" class="bg-green-500 text-white p-2 rounded-md w-full hover:bg-green-600">
                Login
             </button>
          </form>
        </div>
      </div>
  </div>

</body>