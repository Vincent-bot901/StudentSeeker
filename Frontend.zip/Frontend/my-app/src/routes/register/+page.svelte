

<script>
  import { user } from '$lib/index';
  import { goto } from '$app/navigation';
  let username = '';
  let password = '';
  let email = '';
  let loginEmail = '';
  let loginPassword = '';

  const register = () => {
    event.preventDefault(); 
    
    if (username != '' && password != '') {
    const userInfo = { username, email, password };
    user.set(userInfo);
    goto('./cv-gruppe');
      }
    else {
      console.log('JOOO PUT INFO IN')
    }
  }

  const logincheck = () => {
    if (loginEmail == 'vincentmemphis@gmail.com' & loginPassword == 'Vv000')  {
      console.log('nice')
  }
}

</script>

<body>
  
  <header>
  
    <div class="bg-white text-blue-500">
      <div class="container mx-auto flex justify-between items-center py-4">
        <div>
          <button class=" font-mono  font-bold text-5xl px-4 rounded">
              <a href="/" >StudentSeeker</a>
            </button>
        </div>
      </div>
  </div>



  </header>

  <div class="container mx-auto h-screen">
  <h1 class="text-center text-3xl font-bold"> Tilmeld dig nu!</h1>
    <div class="container mx-auto flex justify-center items-center h-screen">
      
        <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
          <h1 class="text-2xl font-bold mb-6">Register or Login</h1>
      
          <form>
           
            <div class="mb-4">
              <label for="username" class="block text-sm font-medium text-gray-600">Username</label>
              <input bind:value={username} type="text" autocomplete="given-name" id="username" name="username" class="mt-1 p-2 w-full border rounded-md">
            </div>
      
            <div class="mb-4">
              <label for="email" class="block text-sm font-medium text-gray-600">Email</label>
              <input bind:value={email} type="email" autocomplete="given-name" id="email" name="email" class="mt-1 p-2 w-full border rounded-md">
            </div>
      
            <div class="mb-4">
              <label for="password" class="block text-sm font-medium text-gray-600">Password</label>
              <input bind:value={password} type="password" autocomplete="given-name" id="password" name="password" class="mt-1 p-2 w-full border rounded-md">
            </div>
            
            <button on:click={register}  type="submit" class="bg-blue-500 text-white p-2 rounded-md w-full hover:bg-blue-600">
                Register
            </button>
          
          </form>
      
          
          <div class="flex items-center my-6">
            <div class="border-t border-gray-400 flex-1"></div>
            <span class="mx-2 text-gray-600">or</span>
            <div class="border-t border-gray-400 flex-1"></div>
          </div>
      
          
          <form>
            <div class="mb-4">
              <label for="loginEmail" class="block text-sm font-medium text-gray-600">Email</label>
              <input bind:value= {loginEmail} type="email" autocomplete="given-name" id="loginEmail" name="loginEmail" class="mt-1 p-2 w-full border rounded-md">
            </div>
      
            <div class="mb-4">
              <label for="loginPassword" class="block text-sm font-medium text-gray-600">Password</label>
              <input bind:value= {loginPassword} type="password" autocomplete="given-name" id="loginPassword" name="loginPassword" class="mt-1 p-2 w-full border rounded-md">
            </div>
            
            <button on:click={logincheck} type="submit" class="bg-green-500 text-white p-2 rounded-md w-full hover:bg-green-600">
                Login
             </button>
          </form>
        </div>
      </div>
  </div>

</body>