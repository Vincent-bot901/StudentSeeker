<script>
  
  import { user } from '$lib/index';
    
  let filteredStrings;

  const imgpressed = (area) => {
 
  for (let i = 0; i < list.length; i++) {

    if (area === list[i]) {
      switch (i) {
        case 0:
          Tech = Tech === 'pressed' ? '' : 'pressed';
          break;
        case 1:
          Healthcare = Healthcare === 'pressed' ? '' : 'pressed';
          break;
      }
      break; 
    }
  }
};

const JobNames = [
    "Retail Associate",          
    "Server/Waitstaff",          
    "Internships",               
    "Freelance Writing",         
    "Tutor",                     
    "Research Assistant",
    "Data Entry Clerk",        
    "Campus Ambassador",       
    "Graphic Design",          
    "Social Media Manager",   
    "Fitness Instructor",     
    "Assistant",
    "Data Entry Clerk",        
    "Campus Ambassador",       
    "Graphic Design",          
    "Social Media Manager",   
    "Fitness Instructor",     
    "Assistant" , 
    "Retail Associate",          
    "Server/Waitstaff",          
    "Internships",               
    "Freelance Writing",         
    "Tutor",                     
    "Research Assistant",
    "Data Entry Clerk",        
    "Campus Ambassador",       
    "Graphic Design",          
    "Social Media Manager",   
    "Fitness Instructor",     
    "Assistant",
    "Data Entry Clerk",        
    "Campus Ambassador",       
    "Graphic Design",          
    "Social Media Manager",   
    "Fitness Instructor",     
    "Assistant"             
]


    // Subscribe to the user store
    $: userInfo = $user;
  
    const addInfo = () => {
      filteredStrings = JobNames.filter((value, index) => buttonStates[index]);
      const userTags = filteredStrings;
      user.update((userInfo) => {
        const updatedUserInfo = { ...userInfo, userTags};
        console.log(updatedUserInfo);
        return updatedUserInfo;
      });
    };

  let buttonStates = new Array(34).fill(false);

const toggleButton = (index) => {
  buttonStates[index] = !buttonStates[index];
  console.log(buttonStates)
  console.log(filteredStrings)
};

</script>

  <style>
    .pressed {
      opacity: 0.6;
    }
  </style>
  
  <header>
    <div class="bg-white text-blue-500">
      <div class="container mx-auto flex justify-between items-center py-4">
        <div>
          <button class="font-mono font-bold text-5xl px-4 rounded">
            <a href="/">ZEEK</a>
          </button>
        </div>
      </div>
    </div>
  </header>

  <body>
    <div class="container mx-auto h-screen flex justify-center items-start">
      <div class="container mx-auto text-black shadow-xl rounded-lg max-h-[calc(100vh-4rem)] overflow-y-auto">
        <h1 class="text-center text-4xl font-mono font-bold py-16"> What areas do you want to work in {userInfo.firstname}?</h1>
        <div class="px-16 py-2">
          {#each buttonStates as state, index (index)}
          <button on:click={() => toggleButton(index)}>
            <div class="mb-4 px-2 py-2 rounded-full" class:pressed={state}>
              <div class="border border-gray-500 bg-blue-500 px-2 py-5 rounded-lg">
                <p class="text-white font-bold text-center">{JobNames[index]}</p>
              </div>
            </div>
          </button>
          {/each}
        </div>
        <div class="container mx-auto flex flex-col justify-center items-center py-8">
          <div class="text-blue-500 font-bold text-center border border-gray-500 rounded-md">
            <button on:click={addInfo} type="submit" class="bg-white font-bold text-3xl bg-blue-500 py-2 px-6 rounded-md w-full hover:bg-gray-200">
              Next step
            </button>
          </div>
        </div>
      </div>
    </div>
  </body>
  